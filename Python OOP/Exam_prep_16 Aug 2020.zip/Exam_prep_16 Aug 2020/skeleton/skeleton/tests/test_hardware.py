from unittest import TestCase, main
from project.hardware.hardware import Hardware
from project.software.software import Software


class TestHardware(TestCase):
    def setUp(self):
        self.hardware = Hardware("Test", "Heavy", 20, 10)
        self.software1 = Software("Soft", "Light", 5, 6)
        self.software2 = Software("Soft2", "Light", 50, 6)
        self.software3 = Software("Soft3", "Light", 5, 60)

    def test_init(self):
        self.assertEqual("Test", self.hardware.name)
        self.assertEqual("Heavy", self.hardware.type)
        self.assertEqual(20, self.hardware.capacity)
        self.assertEqual(10, self.hardware.memory)
        self.assertEqual([], self.hardware.software_components)

    def test_install_no_capacity_exception(self):
        with self.assertRaises(Exception) as ex:
            self.hardware.install(self.software2)
        self.assertEqual("Software cannot be installed", str(ex.exception))

    def test_install_no_memory_exception(self):
        with self.assertRaises(Exception) as ex:
            self.hardware.install(self.software3)
        self.assertEqual("Software cannot be installed", str(ex.exception))

    def test_correct_install(self):
        self.hardware.install(self.software1)
        self.assertEqual([self.software1], self.hardware.software_components)

    def test_uninstall(self):
        self.hardware.install(self.software1)
        self.hardware.uninstall(self.software1)
        self.assertEqual([], self.hardware.software_components)


if __name__ == "__main__":
    main()