class Hardware:
    def __init__(self, name, type, capacity, memory):
        self.name = name
        self.type = type
        self.capacity = capacity
        self.memory = memory
        self.software_components = []
        # self.used_capacity = 0
        # self.used_memory = 0
    #
    # @property
    # def type(self):
    #     return self.__type
    #
    # @type.setter
    # def type(self, value):
    #     if type in ["Heavy", "Power"]:
    #         self.__type = value

    def install(self, software):
        # if software.capacity_consumption <= self.capacity - self.used_capacity\
        #         and software.memory_consumption <= self.memory - self.used_memory:
        #     self.software_components.append(software)
        #     self.used_capacity += software.capacity_consumption
        #     self.used_memory += software.memory_consumption
        if self.capacity >= software.capacity and self.memory >= software.memory:
            self.software_components.append(software)
        else:
            raise Exception("Software cannot be installed")

    def uninstall(self, software):
        if software in self.software_components:
            self.software_components.remove(software)
            # self.used_capacity -= software.capacity_consumption
            # self.used_memory -= software.memory_consumptio



