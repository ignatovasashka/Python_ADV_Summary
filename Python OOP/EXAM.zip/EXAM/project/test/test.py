from project.pet_shop import PetShop
from unittest import TestCase, main


class TestPetShop(TestCase):
    def setUp(self):
        self.psh = PetShop("Test")

    def test_init(self):
        self.assertEqual("Test", self.psh.name)
        self.assertEqual({}, self.psh.food)
        self.assertEqual([], self.psh.pets)

    def test_add_food_invalid_quantity(self):
        with self.assertRaises(ValueError) as ex:
            self.psh.add_food("Test", -2)
        self.assertEqual("Quantity cannot be equal to or less than 0", str(ex.exception))

    def test_add_food(self):
        self.psh.add_food("bones", 3)
        self.assertEqual({"bones": 3}, self.psh.food)

    def test_add_food_message(self):
        result = self.psh.add_food("bones", 3)
        self.assertEqual("Successfully added 3.00 grams of bones.", result)

    def test_add_pet(self):
        self.psh.add_pet("Test")
        self.psh.add_pet("Test1")
        self.assertEqual(["Test", "Test1"], self.psh.pets)
        result = self.psh.add_pet("Test")
        self.assertEqual("Successfully added", result)



    def test_add_pet_invalid(self):
        with self.assertRaises(Exception) as ex:
            self.psh.add_pet("Test")
            self.psh.add_pet("Test")
        self.assertEqual("Cannot add a pet with the same name", str(ex.exception))

    def test_feed_pet_invalid(self):
        with self.assertRaises(Exception) as ex:
            self.psh.feed_pet("bones", "Sharo")
        self.assertEqual("Please insert a valid pet name", str(ex.exception))

    def test_feed_pet_no_such_food(self):
        self.psh.add_food("bones", 3)
        self.psh.add_pet("Sharo")
        result = self.psh.feed_pet("fish", "Sharo")
        self.assertEqual("You do not have fish", result)

    def test_feed_pet(self):
        self.psh.add_food("bones", 3)
        self.psh.add_pet("Sharo")
        result = self.psh.feed_pet("bones", "Sharo")
        self.assertEqual("Adding food...", result)

    def test_feed_pet_more_than_100(self):
        self.psh.add_food("bones", 10000)
        self.psh.add_pet("Sharo")
        result = self.psh.feed_pet("bones", "Sharo")
        self.assertEqual("Sharo was successfully fed", result)

    def test_repr(self):
        self.psh.add_food("bones", 10000)
        self.psh.add_pet("Sharo")
        self.psh.add_pet("Sharo2")
        result = self.psh.__repr__()
        self.assertEqual('Shop Test:\n'+'Pets: Sharo, Sharo2', result)


if __name__ == '__main__':
    main()
