﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _06._List_Manipulation_Basics
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> numbers = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();
            List<int> originalNumbers = numbers;
            string input = Console.ReadLine();

            while (input != "end")
            {
                List<string> command = input.Split().ToList();

                switch (command[0])
                {
                    case "Add": numbers.Add(int.Parse(command[1])); break;
                    case "Remove": numbers.Remove(int.Parse(command[1])); break;
                    case "RemoveAt": numbers.RemoveAt(int.Parse(command[1])); break;
                    case "Insert": numbers.Insert(int.Parse(command[2]), int.Parse(command[1])); break;
                    case "Contains": Contains(int.Parse(command[1], numbers)); break;
                    case "PrintEven": PrintEven(numbers); break;
                    case "PrintOdd": PrintOdd(numbers); break;
                    case "GetSum": GetSum(numbers); break;
                    case "Filter": Filter(numbers, command[1], int.Parse(command[2])); break;
                }

                input = Console.ReadLine();
            }

            if (numbers != originalNumbers)
            {
                Console.WriteLine(string.Join(' ', numbers));
            }
        }

        private static void Filter(List<int> numbers, string condition, int number)
        {
            for (int i = 0; i < numbers[i]; i++)
            {
                if (condition == "<")
                {
                    if (numbers[i] < number)
                    {
                        Console.WriteLine(numbers[i]); 
                    }
                }
                else if (condition == ">")
                {
                    if (numbers[i] > number)
                    {
                        Console.WriteLine(numbers[i]);
                    }
                }
                else if (condition == ">=")
                {
                    if (numbers[i] >= number)
                    {
                        Console.WriteLine(numbers[i]);
                    }
                }
                else if (condition == "<=")
                {
                    if (numbers[i] <= number)
                    {
                        Console.WriteLine(numbers[i]);
                    }
                }
            }
        }

        private static void GetSum(List<int> numbers)
        {
            int sum = 0;
            for (int i = 0; i < numbers.Count; i++)
            {
                sum += numbers[i];
            }
            Console.WriteLine(sum);
        }

        private static void PrintOdd(List<int> numbers)
        {
            for (int i = 0; i < numbers.Count; i++)
            {
                if (numbers[i] % 2 != 0)
                {
                    Console.WriteLine(numbers[i]);
                }
            }
        }

        private static void PrintEven(List<int> numbers)
        {
            for (int i = 0; i < numbers.Count; i++)
            {
                if (numbers[i] % 2 == 0)
                {
                    Console.WriteLine(numbers[i]);
                }
            }
            
        }

        private static void Contains(int number, List<int> Numbers)
        {
            for (int i = 0; i < Numbers.Count; i++)
            {
                if (number == Numbers[i])
                {
                    Console.WriteLine("Yes");
                    break;
                }
                else
                {
                    Console.WriteLine("No such number");
                }
            }
        }
    }
}
