﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01Ranking
{
    class Program
    {
        static void Main(string[] args)
        {
            var contestAndPassword = new Dictionary<string, string>();
            var submissionInfo = new Dictionary<string, Dictionary<string, int>>();

            string input = Console.ReadLine();

            while (input != "end of contests")
            {
                var contest = input.Split(":")[0];
                var password = input.Split(":")[1];

                contestAndPassword.Add(contest, password);

                input = Console.ReadLine();
            }

            input = Console.ReadLine();

            while (input != "end of submissions")
            {
                string[] submissionLine = input.Split("=>");

                var contest = submissionLine[0];
                var password = submissionLine[1];
                var username = submissionLine[2];
                var points = int.Parse(submissionLine[3]);

                if (contestAndPassword.ContainsKey(contest))
                {
                    if (contestAndPassword[contest] == password)
                    {
                        if (!submissionInfo.ContainsKey(username))
                        {
                            Dictionary<string,int> contestAndPoints = new Dictionary<string, int>();
                            contestAndPoints.Add(contest, points);
                            submissionInfo.Add(username, contestAndPoints);
                        }
                        else
                        {
                            if (!submissionInfo[username].ContainsKey(contest) )
                            {
                                submissionInfo[username].Add(contest, points);
                            }
                            else if (submissionInfo[username][contest] < points)
                            {
                                submissionInfo[username][contest] = points;
                            }
                        }
                    }
                }

            }

            var nameAndTotalPoints = new Dictionary<string, int>();

            foreach (var item in submissionInfo)
            {
                nameAndTotalPoints.Add(item.Key, item.Value.Values.Sum());
            }

            Console.WriteLine($"Best candidate is {username} with total {total points} points.");


        }
    }
}
