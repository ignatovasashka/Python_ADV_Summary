﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Judge
{
    class Program
    {
        static void Main(string[] args)
        {
            var contests = new Dictionary<string, Dictionary<string, int>>();


            string input = string.Empty;

            while ((input = Console.ReadLine()) != "no more time")
            {
                string[] tokens = input.Split(" -> ");
                string username = tokens[0];
                string contest = tokens[1];
                int points = int.Parse(tokens[2]);

                AddContest(contests, username, contest, points);
            }


            var users = contests
                .SelectMany(x => x.Value)
                .GroupBy(x => x.Key)
                .ToDictionary(x => x.Key, x => x.Sum(y => y.Value));

            foreach (var contest in contests)
            {
                Console.WriteLine($"{contest.Key}: {contest.Value.Count} participants");

                int counter = 1;
                foreach (var user in contest.Value.OrderByDescending(x => x.Value).ThenBy(x => x.Key))
                {
                    Console.WriteLine($"{counter}. {user.Key} <::> {user.Value}");
                    counter++;
                }
            }

            Console.WriteLine("Individual standings:");
            int userCounter = 1;
            foreach (var user in users.OrderByDescending(x => x.Value).ThenBy(x => x.Key))
            {
                Console.WriteLine($"{userCounter}. {user.Key} -> {user.Value}");
                userCounter++;
            }
        }

        private static void AddContest(Dictionary<string, Dictionary<string, int>> contests, string username, string contest, int points)
        {
            if (!contests.ContainsKey(contest))
            {
                contests[contest] = new Dictionary<string, int>();
            }

            if (!contests[contest].ContainsKey(username))
            {
                contests[contest][username] = points;
            }

            if (contests[contest][username] < points)
            {
                contests[contest][username] = points;
            }
        }
    }
}