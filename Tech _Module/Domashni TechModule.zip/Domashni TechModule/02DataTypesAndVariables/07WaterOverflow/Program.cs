﻿using System;

namespace _07WaterOverflow
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfLines = int.Parse(Console.ReadLine());
            int currentQuantity = 0;
            int sumQuantity = 0;

            for (int i = 0; i < numberOfLines; i++)
            {
                currentQuantity = int.Parse(Console.ReadLine());
                if (sumQuantity + currentQuantity <= 255)
                {
                    sumQuantity += currentQuantity;
                }
                else
                {
                    Console.WriteLine("Insufficient capacity!");
                }
            }


            Console.WriteLine(sumQuantity);
        }
    }
}
