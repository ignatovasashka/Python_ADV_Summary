﻿using System;

namespace _02Division
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            bool div2 = (number % 2 == 0);
            bool div3 = (number % 3 == 0);
            bool div6 = (number % 6 == 0);
            bool div7 = (number % 7 == 0);
            bool div10 = (number % 10 == 0);

            if (div10)
            {
                Console.WriteLine("The number is divisible by 10");
            }
            else if (div7)
            {
                Console.WriteLine("The number is divisible by 7");
            }
            else if (div6)
            {
                Console.WriteLine("The number is divisible by 6");
            }
            else if (div3)
            {
                Console.WriteLine("The number is divisible by 3");
            }
            else if (div2)
            {
                Console.WriteLine("The number is divisible by 2");
            }
            else
            {
                Console.WriteLine("Not divisible");

            }
        }
    }
}
