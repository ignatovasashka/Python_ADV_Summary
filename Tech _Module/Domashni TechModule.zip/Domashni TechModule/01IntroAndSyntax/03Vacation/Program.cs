﻿using System;

namespace _03Vacation
{
    class Program
    {
        static void Main(string[] args)
        {
            int peopleCount = int.Parse(Console.ReadLine());
            string typePeople = Console.ReadLine();
            string day = Console.ReadLine();
            double pricePerPerson = 0;
            double totalPrice = 0;

            if (typePeople == "Students")
            {
                switch (day)
                {
                    case "Friday": pricePerPerson = 8.45; break;
                    case "Saturday": pricePerPerson = 9.80; break;
                    case "Sunday": pricePerPerson = 10.46; break;
                }

                totalPrice = pricePerPerson * peopleCount;

                if (peopleCount >= 30)
                {
                    totalPrice = 0.85 * totalPrice;
                }
                  
            }
            else if (typePeople == "Business")
            {
                switch (day)
                {
                    case "Friday": pricePerPerson = 10.90; break;
                    case "Saturday": pricePerPerson = 15.60; break;
                    case "Sunday": pricePerPerson = 16; break;
                }

                totalPrice = pricePerPerson * peopleCount;

                if (peopleCount >= 100)
                {
                    totalPrice -= 10 * pricePerPerson;
                }
            }
            else if (typePeople == "Regular")
            {
                switch (day)
                {
                    case "Friday": pricePerPerson = 15; break;
                    case "Saturday": pricePerPerson = 20; break;
                    case "Sunday": pricePerPerson = 22.50; break;
                }

                totalPrice = pricePerPerson * peopleCount;

                if (peopleCount >= 10 && peopleCount <= 20)
                {
                    totalPrice = 0.95 * totalPrice;
                }
            }

            Console.WriteLine($"Total price: {totalPrice:f2}");
        }
    }
}
