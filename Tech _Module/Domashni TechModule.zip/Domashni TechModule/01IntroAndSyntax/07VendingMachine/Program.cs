﻿using System;

namespace _07VendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            double totalMoneyInserted = 0;
            double price = 0;
            double totalPrice = 0;
            double moneyLeft = 0;

            while (input != "Start")
            {
                double coins = double.Parse(input);
                if (coins == 0.1 || coins == 0.2 || coins == 0.5 || coins == 1 || coins == 2)
                {
                    totalMoneyInserted += coins;
                }
                else
                {
                    Console.WriteLine($"Cannot accept {coins}");
                }

                input = Console.ReadLine();
            }
            input = Console.ReadLine();
            while (input != "End")
            {
                switch (input)
                {
                    case "Nuts": price = 2.0; Console.WriteLine($"Purchased {input.ToLower()}"); break;
                    case "Water": price = 0.7; Console.WriteLine($"Purchased {input.ToLower()}"); break;
                    case "Crisps": price = 1.5; Console.WriteLine($"Purchased {input.ToLower()}"); break;
                    case "Soda": price = 0.8; Console.WriteLine($"Purchased {input.ToLower()}"); break;
                    case "Coke": price = 1.0; Console.WriteLine($"Purchased {input.ToLower()}"); break;
                    default: Console.WriteLine("Invalid product"); break;
                }
                totalPrice += price;

                if (totalPrice > totalMoneyInserted)
                {
                    Console.WriteLine("Sorry, not enough money");
                    totalPrice -= price;
                }

                input = Console.ReadLine();
            }

            moneyLeft = totalMoneyInserted - totalPrice;
            Console.WriteLine($"Change: {moneyLeft:f2}");
        }
    }
}
