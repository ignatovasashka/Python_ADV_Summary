﻿using System;

namespace _08TriangleOfNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i < n+1; i++)
            {
                for (int j = 1; j < i+1; j++)
                {
                    Console.Write($"{i} ");
                }
                Console.WriteLine();
                
            }
        }
    }
}
