﻿using System;

namespace _05Login
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            string input = Console.ReadLine();
            string password = "";
            int length = name.Length - 1;
            int counter = 0;

            while (length >= 0)
            {
                password = password + name[length];
                length--;
            }

            while (input != password)
            {
                counter++;
                if (counter == 4)
                {
                    Console.WriteLine($"User {name} blocked!");
                    break;
                }
                Console.WriteLine("Incorrect password. Try again.");

                input = Console.ReadLine();
                
            }
            if (input == password)
            {
                Console.WriteLine($"User {name} logged in.");

            }
        }
    }
}
