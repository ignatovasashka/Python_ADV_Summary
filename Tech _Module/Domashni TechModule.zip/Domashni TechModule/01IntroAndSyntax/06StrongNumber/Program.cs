﻿using System;

namespace _06StrongNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = int.Parse(Console.ReadLine());
            int digit = 0;
            int factorial = 0;
            int newNumber = 0;

            digit = number % 10;
            newNumber = number / 10;
            while (digit >= 1)
            {
                switch (digit)
                {
                    case 1: factorial += 1; break;
                    case 2: factorial += 1*2; break;
                    case 3: factorial += 1*2*3; break;
                    case 4: factorial += 1*2*3*4; break;
                    case 5: factorial += 1 * 2 * 3 * 4 * 5; break;
                    case 6: factorial += 1 * 2 * 3 * 4 * 5*6; break;
                    case 7: factorial += 1 * 2 * 3 * 4 * 5*6*7; break;
                    case 8: factorial += 1 * 2 * 3 * 4 * 5*6*7*8; break;
                    case 9: factorial += 1 * 2 * 3 * 4 * 5*6*7*8*9; break;      
                }
                digit = newNumber % 10;
                newNumber = newNumber / 10;
            }

            if (factorial == number)
            {
                Console.WriteLine("yes");
            }
            else
            {
                Console.WriteLine("no");
            }

        }
    }
}
