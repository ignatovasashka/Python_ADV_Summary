﻿using System;

namespace _03Arrays_MoreExercises
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfStrings = int.Parse(Console.ReadLine());
            string currentName = "";
            int sumVowels = 0;
            int sumConsonants = 0;
            int totalSum = 0;
            int[] outputArray = new int[numberOfStrings];
            int minValue = 0;

            for (int j = 0; j < numberOfStrings; j++)
            {
                currentName = Console.ReadLine();
                sumVowels = 0;
                sumConsonants = 0;
                totalSum = 0;
                for (int i = 0; i < currentName.Length; i++)
                {
                    if (currentName[i] == 'a' || currentName[i] == 'e' || currentName[i] == 'i' || currentName[i] == 'o' || currentName[i] == 'u' || currentName[i] == 'A'
   || currentName[i] == 'E' || currentName[i] == 'I' || currentName[i] == 'O' || currentName[i] == 'U')
                    {
                        sumVowels += currentName[i]*currentName.Length;
                    }
                    else
                    {
                        sumConsonants += currentName[i]/currentName.Length;
                    }
                }
                totalSum = sumVowels + sumConsonants;

                outputArray[j] = totalSum;
         
            }

            Array.Sort(outputArray);

            for (int l = 0; l < outputArray.Length; l++)
            {
                Console.WriteLine(outputArray[l]);

            }

        }
    }
}
