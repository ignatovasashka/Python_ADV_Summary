﻿using System;

namespace _02PascalTriangle
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
