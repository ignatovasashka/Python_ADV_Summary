﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04ListOperarions
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();

            string input;


            while ((input = Console.ReadLine()) != "End")
            {
                string[] inputLine = input.Split();
                ExecuteCommands(numbers, inputLine);

            }

            Console.WriteLine(string.Join(' ', numbers));
        }

        private static void ExecuteCommands(List<int> numbers, string[] inputLine)
        {
            int currentNumberOfElements = numbers.Count;

            if (inputLine[0] == "Add")
            {
                int addedNumber = int.Parse(inputLine[1]);
                numbers.Add(addedNumber);
                currentNumberOfElements = numbers.Count;

            }
            else if (inputLine[0] == "Insert")
            {
                if (int.Parse(inputLine[2]) >= numbers.Count || int.Parse(inputLine[2]) < 0)
                {
                    Console.WriteLine("Invalid index");
                    
                }
                else
                {
                    int insertedNumber = int.Parse(inputLine[1]);
                    int position = int.Parse(inputLine[2]);
                    numbers.Insert(position, insertedNumber);
                }
             
            }
            else if (inputLine[0] == "Remove")
            {
                if (int.Parse(inputLine[1]) >= numbers.Count || int.Parse(inputLine[1]) < 0)
                {
                    Console.WriteLine("Invalid index");
                }
                else
                {
                    int index = int.Parse(inputLine[1]);
                    numbers.RemoveAt(index);
                }
            }

            else if (inputLine[0] == "Shift" && inputLine[1] == "left")
            {
                if (int.Parse(inputLine[2]) >= numbers.Count || int.Parse(inputLine[2]) < 0)
                {
                    Console.WriteLine("Invalid index");
                }
                else
                {
                    int count = int.Parse(inputLine[2]);

                    for (int i = 0; i < count; i++)
                    {
                        int firstNumber = numbers[0];
                        numbers.Add(firstNumber);
                        numbers.RemoveAt(0);

                    }
                }
            }
            else if (inputLine[0] == "Shift" && inputLine[1] == "right")
            {
                if (int.Parse(inputLine[2]) >= numbers.Count || int.Parse(inputLine[2]) < 0)
                {
                    Console.WriteLine("Invalid index");
                }
                else
                {
                    int count = int.Parse(inputLine[2]);

                    for (int i = 0; i < count; i++)
                    {
                        int lastNumber = numbers[numbers.Count - 1];
                        numbers.Insert(0, lastNumber);
                        numbers.RemoveAt(numbers.Count - 1);

                    }
                }

                    
            }
        }
    }
}
