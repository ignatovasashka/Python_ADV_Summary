﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05BombNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numbers = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToList();

            int[] bombNumberAndPower = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            int bombNumber = bombNumberAndPower[0];
            int power = bombNumberAndPower[1];
            int sum = 0;

            for (int i = 0; i < numbers.Count; i++)
            {
                if (bombNumber == numbers[i])
                {
                    if (numbers.Count-1 - i < power && i < power)
                    {
                        numbers.RemoveRange(0, numbers.Count);
                    }
                    else if (numbers.Count-1 - i < power)
                    {
                        numbers.RemoveRange(i - power, power + 1 + (numbers.Count-1 - i));
                    }
                    else if (i < power)
                    {
                        numbers.RemoveRange(0, i + 1 + power);
                    }
                    else
                    {
                        numbers.RemoveRange(i - power, power + 1 + power);
                    }

                    i = 0;
                }
            }

            for (int i = 0; i < numbers.Count; i++)
            {
                sum += numbers[i];
            }

            Console.WriteLine(sum);
   
        }
    }
}
