﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03QuestsJournal
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> journal = Console.ReadLine()
                .Split(", ")
                .ToList();

            List<string> command = Console.ReadLine()
                .Split(" - ")
                .ToList();

            while (command[0] != "Retire!")
            {

            }
        }
    }
}
