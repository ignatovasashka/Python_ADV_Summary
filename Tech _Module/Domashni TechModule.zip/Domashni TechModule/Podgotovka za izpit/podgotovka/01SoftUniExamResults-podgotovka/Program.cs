﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01SoftUniExamResults_podgotovka
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split("-");
            var studentsAndPoints = new Dictionary<string, int>();
            var submissionsCount = new Dictionary<string, int>();

            while (input[0] != "exam finished")
            {
                string username = input[0];

                if (input[1] != "banned")
                {
                    string language = input[1];
                    int points = int.Parse(input[2]);

                    if (!studentsAndPoints.ContainsKey(username))
                    {
                        studentsAndPoints[username] = points;
                    }
                    else if (points > studentsAndPoints[username])
                    {
                        studentsAndPoints[username] = points;
                    }

                    if (!submissionsCount.ContainsKey(language))
                    {
                        submissionsCount[language] = 1;
                    }
                    else
                    {
                        submissionsCount[language]++;
                    }
                }
                else
                {
                    if (studentsAndPoints.ContainsKey(username))
                    {
                        studentsAndPoints.Remove(username);
                    }
                }

                input = Console.ReadLine().Split("-");
            }

            Console.WriteLine("Results:");

            foreach (var item in studentsAndPoints
                .OrderByDescending(x=>x.Value)
                .ThenBy(x=>x.Key))
            {
                Console.WriteLine($"{item.Key} | {item.Value}");
            }

            Console.WriteLine("Submissions:");

            foreach (var item in submissionsCount
                .OrderByDescending(x => x.Value)
                .ThenBy(x => x.Key))
            {
                Console.WriteLine($"{item.Key} - {item.Value}");
            }
        }
    }
}
