﻿using System;

namespace _03Calculations
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());

            switch (input)
            {
                case "add": AddsTwoNumbers(a, b); break;
                case "multiply": MultipliesTwoNumbers(a, b); break;
                case "subtract": SubstractsTwoNumbers(a, b); break;
                case "divide": DividesTwoNumbers(a, b); break;

            }
        }

        private static void DividesTwoNumbers(int a, int b)
        {
            Console.WriteLine(a / b);
        }

        private static void SubstractsTwoNumbers(int a, int b)
        {
            Console.WriteLine(a - b);
        }

        private static void MultipliesTwoNumbers(int a, int b)
        {
            Console.WriteLine(a * b);
        }

        private static void AddsTwoNumbers(int a, int b)
        {
            Console.WriteLine(a+b);
        }
    }
}
