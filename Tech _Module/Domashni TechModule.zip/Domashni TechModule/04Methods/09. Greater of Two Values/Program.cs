﻿using System;

namespace _09._Greater_of_Two_Values
{
    class Program
    {
        static void Main(string[] args)
        {
            string typeOfInput = Console.ReadLine();
            string firstValue = Console.ReadLine();
            string secondValue = Console.ReadLine();

            string maxValue = GetMax(typeOfInput, firstValue, secondValue);
            Console.WriteLine(maxValue);
        }

        private static string GetMax(string typeOfValues, string firstValue, string secondValue)
        {
            if (typeOfValues == "int")
            {
                int firstValueToInt = int.Parse(firstValue);
                int secondValueToInt = int.Parse(secondValue);

                if (firstValueToInt > secondValueToInt)
                {
                    return firstValue;
                }
                else
                {
                    return secondValue;
                }
            }
            else if (typeOfValues == "char")
            {
                char firstValueToChar = char.Parse(firstValue);
                char secondValueToChar = char.Parse(secondValue);

                if (firstValueToChar > secondValueToChar)
                {
                    return firstValue;
                }
                else
                {
                    return secondValue;
                }
            }
            else
            {
                if (firstValue.CompareTo(secondValue) > 0)
                {
                    return firstValue;
                }
                else
                {
                    return secondValue;
                }
                
                
                //int fistSum = 0;
                //int secondSum = 0;
                //
                //for (int i = 0; i < firstValue.Length; i++)
                //{
                //    fistSum += firstValue[i];
                //}
                //for (int i = 0; i < secondValue.Length; i++)
                //{
                //    secondSum += secondValue[i];
                //}

                //if (fistSum > secondSum)
                //{
                //    return firstValue;
                //}
                //else
                //{
                //    return secondValue;
                //}

            }
            
            //char[] first = firstValue.ToCharArray();
            //char[] second = secondValue.ToCharArray();
            //int firstSum = 0;
            //int secondSum = 0;
            //
            //for (int i = 0; i < first.Length; i++)
            //{
            //    firstSum += first[i];
            //}
            //for (int j = 0; j < second.Length; j++)
            //{
            //    secondSum += second[j];
            //}
            //
            //if (firstSum > secondSum)
            //{
            //    return firstValue;
            //}
            //else
            //{
            //    return secondValue;
            //}
        }
    }
}
