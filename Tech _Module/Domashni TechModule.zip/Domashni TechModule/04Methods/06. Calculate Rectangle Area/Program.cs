﻿using System;

namespace _06._Calculate_Rectangle_Area
{
    class Program
    {
        static void Main(string[] args)
        {
            double width = double.Parse(Console.ReadLine());
            double height = double.Parse(Console.ReadLine());

            double area = CalcuatesRectangleArea(width, height);

            Console.WriteLine(area);
        }

        private static double CalcuatesRectangleArea(double width, double height)
        {
            return width * height;
        }
    }
}
