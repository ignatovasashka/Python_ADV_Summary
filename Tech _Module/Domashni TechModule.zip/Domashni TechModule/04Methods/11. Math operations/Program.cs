﻿using System;

namespace _11._Math_operations
{
    class Program
    {
        static void Main(string[] args)
        {
            int firstNumber = int.Parse(Console.ReadLine());
            string calculation = Console.ReadLine();
            int secondNumber = int.Parse(Console.ReadLine());

            Console.WriteLine(Calculate(firstNumber, calculation, secondNumber));

        }

        private static double Calculate(int firstNumber, string calculation, int secondNumber)
        {
            double result = 0;

            switch (calculation)
            {
                case "/": result = (double)firstNumber/secondNumber; break;
                case "*": result = (double)firstNumber*secondNumber; break;
                case "+": result = (double)firstNumber+secondNumber; break;
                case "-": result = (double)firstNumber-secondNumber; break;

            }

            return result;
        }
    }
}
