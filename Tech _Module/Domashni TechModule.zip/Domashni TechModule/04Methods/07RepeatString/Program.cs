﻿using System;
using System.Text;

namespace _07RepeatString
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = Console.ReadLine();
            int count = int.Parse(Console.ReadLine());
            string repeatedString = RepeatedString(str, count);
            Console.WriteLine(repeatedString);
        }

        private static string RepeatedString(string str, int count)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < count; i++)
            {
                sb.Append(str);
            }
            return sb.ToString();
        }
    }
}
