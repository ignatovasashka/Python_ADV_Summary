﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main()
        {
            int firstNumber = int.Parse(Console.ReadLine());
            int secondNumber = int.Parse(Console.ReadLine());
            int thirdNumber = int.Parse(Console.ReadLine());

            Console.WriteLine(SmallestOfThreeNumbers(firstNumber, secondNumber, thirdNumber));
        }

        private static int SmallestOfThreeNumbers(int firstNumber, int secondNumber, int thirdNumber)
        {
            int smallestNumber = int.MaxValue;

            if (firstNumber < smallestNumber)
            {
                smallestNumber = firstNumber;
            }
            if (secondNumber < smallestNumber)
            {
                smallestNumber = secondNumber;
            }
            if (thirdNumber < smallestNumber)
            {
                smallestNumber = thirdNumber;
            }

            return smallestNumber;
        }
    }
}
