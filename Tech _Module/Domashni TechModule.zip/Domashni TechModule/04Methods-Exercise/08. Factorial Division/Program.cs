﻿using System;

namespace _08._Factorial_Division
{
    class Program
    {
        static void Main(string[] args)
        {
            long firstNum = long.Parse(Console.ReadLine());
            long secondNum = long.Parse(Console.ReadLine());

            long firstNumFactorial = GetFactorial(firstNum);
            long secondNumFactorial = GetFactorial(secondNum);

            double finalResult = (double)firstNumFactorial / secondNumFactorial;

            Console.WriteLine($"{finalResult:f2}");
        }

        private static long GetFactorial(long number)
        {
            long factorial = 1;
            for (int i = 2; i <= number; i++)
            {
                factorial *= i;
            }
            return factorial;
        }
    }
}
