﻿using System;

namespace _02VowelsCount
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            VowelsCount(input);
        }

        private static void VowelsCount(string singleString)
        {
            string newSingleString = singleString.ToLower();
            int counter = 0;
            for (int i = 0; i < newSingleString.Length; i++)
            {
                if (newSingleString[i] == 'a' || newSingleString[i] == 'e' || newSingleString[i] == 'i' || newSingleString[i] == 'o' || newSingleString[i] == 'u')
                {
                    counter++;
                }
            }

            Console.WriteLine(counter);
        }
    }
}
