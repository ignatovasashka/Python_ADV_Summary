﻿using System;

namespace _03CharactersInRange
{
    class Program
    {
        static void Main(string[] args)
        {
            char firstCharacter = char.Parse(Console.ReadLine());
            char secondCharacter = char.Parse(Console.ReadLine());

            PrintCharactersInRange(firstCharacter, secondCharacter);
        }

        private static void PrintCharactersInRange(char firstChar, char lastChar)
        {
            if (firstChar < lastChar)
            {
                for (int i = firstChar + 1; i < lastChar; i++)
                {
                    if (i == lastChar -1)
                    {
                        Console.Write((char)i);
                    }
                    else
                    {
                        Console.Write((char)i + " ");
                    }

                }
            }
            else
            {
                for (int i = lastChar +1; i < firstChar; i++)
                {
                    if (i == firstChar+1)
                    {
                        Console.Write((char)i);
                    }
                    else
                    {
                        Console.Write((char)i + " ");
                    }

                }
            }

            Console.WriteLine();
            
        }
    }
}
