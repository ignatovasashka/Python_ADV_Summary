﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _07StudentAacademy
{
    class Program
    {
        static void Main(string[] args)
        {
            int pairsOfRows = int.Parse(Console.ReadLine());

            var studentsGrades = new Dictionary<string, List<double>>();
            var studentsAverageGrades = new Dictionary<string, double>();

            for (int i = 0; i < pairsOfRows; i++)
            {
                string student = Console.ReadLine();
                double grade = double.Parse(Console.ReadLine());
                List<double> grades = new List<double>();
                grades.Add(grade);

                if (!studentsGrades.ContainsKey(student))
                {
                    studentsGrades.Add(student, grades);
                }
                else
                {
                    studentsGrades[student].Add(grade);
                }
            }

            foreach (var item in studentsGrades)
            {
                studentsAverageGrades.Add(item.Key, item.Value.Average());
            }
            //foreach (var item in studentsAverageGrades.Where(x => x.Value >= 4.50))
            //{
            //    studentsAverageGrades.Remove(item.Key);
            //}

            foreach (var item in studentsAverageGrades.Where(x => x.Value >= 4.50).OrderByDescending(x => x.Value))
            {
                Console.WriteLine($"{item.Key} -> {item.Value:f2}");
            }
        }
    }
}
