﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _06Courses
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> courseAndStudent = Console.ReadLine().Split(" : ").ToList();
            var registeredStudents = new Dictionary<string, string>();
            var studentsCountInCourses = new Dictionary<string, int>();
            int count = 1;

            while (courseAndStudent[0] != "end")
            {
                string course = courseAndStudent[0];
                string student = courseAndStudent[1];

                if (!studentsCountInCourses.ContainsKey(course))
                {
                    studentsCountInCourses.Add(course, count);
                }
                else
                {
                    studentsCountInCourses[course]++;
                }

                registeredStudents.Add(student, course);

                courseAndStudent = Console.ReadLine().Split(" : ").ToList();
            }

            foreach (var item in studentsCountInCourses.OrderByDescending(x => x.Value))
            {
                Console.WriteLine($"{item.Key}: {item.Value}");
                foreach (var person in registeredStudents.OrderBy(x => x.Key).Where(x => x.Value == item.Key))
                {
                    Console.WriteLine($"-- {person.Key}");
                }
            }


        }
    }
}
