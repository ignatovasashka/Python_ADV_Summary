﻿namespace _04Orders
{
    internal class Dictionary<T>
    {
        public Dictionary()
        {
        }
    }
}