﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _04Orders
{
    class Program
    {
        static void Main(string[] args)
        {
            var products = new Dictionary<string, List<double>>();
            var totalPrices = new List<double>();

            List<string> input = Console.ReadLine().Split().ToList();

            while (input[0] != "buy")
            {
                string product = input[0];
                double price = double.Parse(input[1]);
                double quantity = double.Parse(input[2]);


                if (!products.ContainsKey(input[0]))
                {
                    var pricesAndQuantities = new List<double>();

                    pricesAndQuantities.Add(double.Parse(input[1]));
                    pricesAndQuantities.Add(double.Parse(input[2]));

                    products[input[0]] = pricesAndQuantities;
                }
                else
                {

                    products[product][0] = price;
                    products[product][1] += quantity;

                    //pricesAndQuantities[1] += double.Parse(input[2]);
                    //pricesAndQuantities[0] = double.Parse(input[1]);
                }




                input = Console.ReadLine().Split().ToList();
            }


            foreach (var item in products)
            {

                double totalPrice = item.Value[0] * item.Value[1];
                Console.WriteLine($"{item.Key} -> {totalPrice:f2}");

            }
        }
    }
}
