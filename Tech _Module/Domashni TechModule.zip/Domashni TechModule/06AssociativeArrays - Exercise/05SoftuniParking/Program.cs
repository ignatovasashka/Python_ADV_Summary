﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _05SoftuniParking
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            var registered = new Dictionary<string, string>();

            for (int i = 0; i < n; i++)
            {
                List<string> command = Console.ReadLine().Split().ToList();
                string currentCommand = command[0];
                string username = command[1];

                if (currentCommand == "register")
                {
                    string licensePlateNumber = command[2];
                    if (!registered.ContainsKey(username))
                    {
                        registered.Add(username, licensePlateNumber);
                        Console.WriteLine($"{username} registered {licensePlateNumber} successfully");
                    }
                    else
                    {
                        Console.WriteLine($"ERROR: already registered with plate number {licensePlateNumber}");
                    }
                }
                else
                {
                    if (!registered.ContainsKey(username))
                    {
                        Console.WriteLine($"ERROR: user {username} not found");
                    }
                    else
                    {
                        registered.Remove(username);
                        Console.WriteLine($"{username} unregistered successfully");
                    }
                }
            }

            foreach (var item in registered)
            {
                Console.WriteLine(item.Key + " => " + item.Value);
            }

        }
    }
}
