﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01CountChairsInAString
{
    class Program
    {
        static void Main(string[] args)
        {
            var charactersCount = new Dictionary<char, int>();

            string input = Console.ReadLine();

            for (int i = 0; i < input.Length; i++)
            {
                
                if (charactersCount.ContainsKey(input[i]))
                {
                    charactersCount[input[i]]++;
                }
                else
                {
                    charactersCount[input[i]] = 1;
                }
            }

            charactersCount.Remove(' ');
                
            
            foreach (var item in charactersCount)
            {
                Console.WriteLine($"{item.Key} -> {item.Value}");
            }
            
        }
    }
}
