﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _08CompanyUsers
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> companyAndEmployeeID = Console.ReadLine().Split(" -> ").ToList();

            var employeesInEachCompany = new Dictionary<string, List<string>>();
            //List<string> employeeIDs = new List<string>();

            while (companyAndEmployeeID[0] != "End")
            {
                string company = companyAndEmployeeID[0];
                string employeeID = companyAndEmployeeID[1];

                if (!employeesInEachCompany.ContainsKey(company))
                {
                    List<string> employeeIDs = new List<string>();

                    //employeeIDs.Clear();
                    employeeIDs.Add(employeeID);

                    employeesInEachCompany.Add(company, employeeIDs);
                }
                else if (employeesInEachCompany.ContainsKey(company) && !employeesInEachCompany[company].Contains(employeeID))
                {
                    employeesInEachCompany[company].Add(employeeID);
                }

                companyAndEmployeeID = Console.ReadLine().Split(" -> ").ToList();
            }

            foreach (var item in employeesInEachCompany.OrderBy(x => x.Key))
            {
                Console.WriteLine($"{item.Key}");
                foreach (var id in employeesInEachCompany[item.Key])
                {
                    Console.WriteLine($"-- {id}");
                }
            }

        }
    }
}
