﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03LegendaryFarming
{
    class Program
    {
        static void Main(string[] args)
        {
            var dictionary = new Dictionary<string, int>();
            dictionary["fragments"] = 0;
            dictionary["motes"] = 0;
            dictionary["shards"] = 0;

            var junkElements = new Dictionary<string, int>();

            while (true)
            {
                bool haveWinner = false;

                var tokens = Console.ReadLine().ToLower().Split().ToArray();

                for (int i = 0; i < tokens.Length; i+=2)
                {
                    string type = tokens[i + 1];
                    int quantity = int.Parse(tokens[i]);

                    if (type == "motes" || type == "fragments" || type == "shards")
                    {
                        if (!dictionary.ContainsKey(type))
                        {
                            dictionary.Add(type, quantity);
                        }
                        else
                        {
                            dictionary[type] += quantity;

                        }
                    }
                    else
                    {
                        if (!junkElements.ContainsKey(type))
                        {
                            junkElements.Add(type, quantity);
                        }
                        else
                        {
                            junkElements[type] += quantity;
                        }
                    }

                    if (dictionary["motes"] >= 250 || dictionary["shards"] >= 250 || dictionary["fragments"] >= 250)
                    {
                        dictionary[type] = dictionary[type] - 250;

                        if (type == "shards")
                        {
                            Console.WriteLine($"Shadowmourne obtained!");
                        }
                        else if (type == "fragments")
                        {
                            Console.WriteLine($"Valanyr obtained!");
                        }
                        else if (type == "motes")
                        {
                            Console.WriteLine($"Dragonwrath obtained!");
                        }

                        haveWinner = true;
                        break;
                    }
                }

                if (haveWinner)
                {
                    break;
                }
            }

            foreach (var kvp in dictionary.OrderByDescending(x=>x.Value).ThenBy(x=>x.Key))
            {
                Console.WriteLine($"{kvp.Key}: {kvp.Value}");
            }

            foreach (var kvp in junkElements.OrderBy(x=>x.Key))
            {
                Console.WriteLine($"{kvp.Key}: {kvp.Value}");
            }
        }
    }
}
