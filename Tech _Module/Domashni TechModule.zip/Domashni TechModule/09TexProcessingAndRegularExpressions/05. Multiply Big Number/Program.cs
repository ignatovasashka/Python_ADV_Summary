﻿using System;

namespace _05._Multiply_Big_Number
{
    class Program
    {
        static void Main(string[] args)
        {
            string bigNumber = Console.ReadLine().TrimStart('0');
            string shortNumber = Console.ReadLine().TrimStart('0');

            string result = (decimal.Parse(bigNumber) * decimal.Parse(shortNumber)).ToString();
            Console.WriteLine(result);
        }
    }
}
