﻿using System;
using System.Text;

namespace _06ReplaceRepeatingChars
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            StringBuilder sb = new StringBuilder();
            string previousChar = string.Empty;

            for (int i = 0; i < input.Length; i++)
            {
                string newChar = input[i].ToString();

                if (newChar != previousChar)
                {
                    sb.Append(newChar);

                }

                previousChar = input[i].ToString();
            }

            Console.WriteLine(sb);
        }
    }
}
