﻿using System;
using System.Text;

namespace _07._String_Explosion
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            double power = 0;

            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == '>')
                {
                    double currentPower = char.GetNumericValue(input[i + 1]);
                    power += currentPower;
                }
                else if (char.IsLetterOrDigit(input[i]) && power > 0)
                {
                    input = input.Remove(i, 1);
                    power--;
                    i--;
                }
            }

            Console.WriteLine(input);


        }
    }
}
