﻿using System;
using System.Text.RegularExpressions;

namespace _08MatchNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string pattern = @"(^|(?<=\s))-?\d+(\.\d+)?($|(?=\s))";

            string input = Console.ReadLine();

            MatchCollection matched = Regex.Matches(input, pattern);

            foreach (Match item in matched)
            {
                Console.Write($"{item} ");
            }
        }
    }
}
