﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _03CookingFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<string> allBatches = new List<string>();
            List<int> batchesTotalQualities = new List<int>();
            List<double> batchesAverageQualities = new List<double>();
            List<int> batchesElementsCount = new List<int>();

            int totalQuality = 0;
            double averageQuality = 0;
            int elementsCount = 0;

            while (input != "Bake It!")
            {
                allBatches.Add(input);

                int[] currentBatch = input.Split('#').Select(int.Parse).ToArray();

                for (int i = 0; i < currentBatch.Length; i++)
                {
                    totalQuality += currentBatch[i];
                }

                averageQuality = totalQuality / currentBatch.Length;
                elementsCount = currentBatch.Length;

                batchesTotalQualities.Add(totalQuality);
                batchesAverageQualities.Add(averageQuality);
                batchesElementsCount.Add(elementsCount);

                input = Console.ReadLine();
                totalQuality = 0;
                //averageQuality = 0;
                //elementsCount = 0;

            }

            int maxQuality = batchesTotalQualities.Max();
            int indexOfMaxQuality = batchesTotalQualities.IndexOf(maxQuality);

            for (int i = 0; i < batchesTotalQualities.Count; i++)
            {
                if (batchesTotalQualities[i] == maxQuality && indexOfMaxQuality != i)
                {
                    double maxAverageQuality = batchesAverageQualities.Max();
                    int indexOfMaxAverageQuality = batchesAverageQualities.IndexOf(maxAverageQuality);

                    for (int j = 0; j < batchesAverageQualities.Count; j++)
                    {
                        if (batchesAverageQualities[j] == maxAverageQuality && indexOfMaxAverageQuality != j)
                        {
                            int minElementsCount = batchesElementsCount.Min();
                            int indexOfMinElementsCount = batchesElementsCount.IndexOf(minElementsCount);

                            Console.WriteLine($"Best Batch quality: {batchesTotalQualities[indexOfMinElementsCount]}");
                            Console.WriteLine(string.Join(" ", allBatches[indexOfMinElementsCount].Split('#').ToList()));
                        }
                        else
                        {
                            Console.WriteLine($"Best Batch quality: {batchesTotalQualities[j]}");
                            Console.WriteLine(string.Join(" ", allBatches[j].Split('#').ToList()));
                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"Best Batch quality: {maxQuality}");
                    Console.WriteLine(string.Join(" ", allBatches[indexOfMaxQuality].Split('#').ToList()));
                    break;
                }
            }

        }
    }
}
