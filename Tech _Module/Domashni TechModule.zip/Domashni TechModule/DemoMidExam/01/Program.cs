﻿using System;

namespace _01
{
    class Program
    {
        static void Main(string[] args)
        {
            double budget = double.Parse(Console.ReadLine());
            int students = int.Parse(Console.ReadLine());
            double flourPrice = double.Parse(Console.ReadLine());
            double eggPrice = double.Parse(Console.ReadLine());
            double apronPrice = double.Parse(Console.ReadLine());

            double freePackages = Math.Floor(students / 5.0);

            double totalPriceOfSets = (students-freePackages)*(1 * flourPrice) + students*(10 * eggPrice) + Math.Ceiling(students * 1.20) * apronPrice;

            if (totalPriceOfSets <= budget)
            {
                Console.WriteLine($"Items purchased for {totalPriceOfSets:f2}$.");
            }
            else
            {
                double neededMoney = totalPriceOfSets - budget;
                Console.WriteLine($"{neededMoney:f2}$ more needed.");
            }
        }
    }
}
