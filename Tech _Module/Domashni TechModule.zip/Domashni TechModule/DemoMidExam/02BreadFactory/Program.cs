﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _02BreadFactory
{
    class Program
    {
        static void Main(string[] args)
        {
            int energy = 100;
            int coins = 100;
            string input = Console.ReadLine();
            List<string> workingDayEvents = input.Split('|').ToList();
            //bool isOrderSkipped = false;

            for (int i = 0; i < workingDayEvents.Count; i++)
            {
                string[] currentEvent = workingDayEvents[i].Split('-').ToArray();
                int value = int.Parse(currentEvent[1]);

                if (currentEvent[0] == "rest")
                {
                    if (energy + value <= 100)
                    {
                        energy += value;
                        Console.WriteLine($"You gained {value} energy.");
                        Console.WriteLine($"Current energy: {energy}.");
                    }
                    else
                    {
                        int exceedingPoints = (energy + value) - 100;
                        energy = 100;
                        Console.WriteLine($"You gained {value-exceedingPoints} energy.");
                        Console.WriteLine($"Current energy: {energy}.");
                    }
                }
                else if (currentEvent[0] == "order")
                {

                    if (energy-30 >= 0)
                    {
                        energy -= 30;

                        coins += value;
                        Console.WriteLine($"You earned {value} coins.");
                    }
                    else
                    {
                        energy += 50;
                        Console.WriteLine("You had to rest!");
                        //isOrderSkipped = true;
                    }
                }
                else
                {
                    coins -= value;
                    string ingredient = currentEvent[0];

                    if (coins > 0)
                    {
                        Console.WriteLine($"You bought {ingredient}.");
                    }
                    else
                    {
                        Console.WriteLine($"Closed! Cannot afford {ingredient}.");
                        return;
                    }
                }
            }

            
                Console.WriteLine("Day completed!");
                Console.WriteLine($"Coins: {coins}");
                Console.WriteLine($"Energy: {energy}");
            

        }
    }
}
