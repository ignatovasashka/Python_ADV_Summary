﻿using System;
using System.Linq;

namespace _03._Zig_Zag_Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] fromLeftDiagonal = new int[n];
            int[] fromRightDiagonal = new int[n];

            for (int i = 0; i < n; i++)
            {
                
                int[] numbers = Console.ReadLine()
                    .Split()
                    .Select(int.Parse)
                    .ToArray();

                if (i % 2 == 0)
                {
                    fromLeftDiagonal[i] = numbers[0];
                    fromRightDiagonal[i] = numbers[1];
                }
                else
                {
                    fromLeftDiagonal[i] = numbers[1];
                    fromRightDiagonal[i] = numbers[0];
                }
            }

            Console.WriteLine(String.Join(" ", fromLeftDiagonal));

            Console.WriteLine(String.Join(" ", fromRightDiagonal));
        }
    }
}
