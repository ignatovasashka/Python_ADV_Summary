﻿using System;
using System.Linq;

namespace _01Train
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int sum = 0;
            int[] passengers = new int[n];
            for (int i = 0; i < n; i++)
            {
                passengers[i] = int.Parse(Console.ReadLine());
                sum += passengers[i];
            }

            foreach (var item in passengers)
            {
                string allElements = item + " ";
                Console.Write(allElements.Trim());

            }
            Console.WriteLine();
            Console.WriteLine(sum);
        }
    }
}
