﻿using System;
using System.Linq;

namespace _10LadyBugs
{
    class Program
    {
        static void Main(string[] args)
        {
            int fieldSize = int.Parse(Console.ReadLine());
            int[] initialIndexes = Console.ReadLine().Split().Select(int.Parse).ToArray();
            string input = Console.ReadLine();
            string[] inputLine = input.Split().ToArray();
            int ladybugIndex = 0;
            string direction = "";
            int flyLength = 0;

            while (input != "end")
            {
                ladybugIndex = int.Parse(inputLine[0]);
                direction = inputLine[1];
                flyLength = int.Parse(inputLine[2]);

                for (int i = 0; i < initialIndexes.Length; i++)
                {
                    if (ladybugIndex == i && initialIndexes[i] == 1)
                    {
                        if (direction == "right")
                        {
                            initialIndexes[i] = 0;
                            i = ladybugIndex + flyLength;
                            while (initialIndexes[i] == 1 && i<=initialIndexes.Length)
                            {
                                i++;
                            }
                            initialIndexes[i] = 1;
                        }
                        else
                        {
                            initialIndexes[i] = 0;
                            i = ladybugIndex - flyLength;
                            while (initialIndexes[i] == 1 && i <= initialIndexes.Length)
                            {
                                i--;
                            }
                            initialIndexes[i] = 1;
                        }
                    }
                }

                inputLine = Console.ReadLine().Split().ToArray();

            }

            Console.WriteLine(String.Join(' ', initialIndexes));

        }
    }
}
