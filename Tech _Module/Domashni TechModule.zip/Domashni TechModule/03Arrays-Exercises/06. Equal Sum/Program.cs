﻿using System;
using System.Linq;

namespace _06._Equal_Sum
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] myArray = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            int leftSum = 0;
            int rightSum = 0;
            bool isEqual = false;

            for (int i = 0; i < myArray.Length; i++)
            {
                leftSum = 0;
                rightSum = 0;
                if (i == (myArray.Length - 1))
                {
                    rightSum = 0;
                }
                else
                {
                    for (int j = i + 1; j < myArray.Length; j++)
                    {
                        rightSum += myArray[j];
                    }
                }

                if (i == 0)
                {
                    leftSum = 0;
                }
                else
                {
                    for (int k = 0; k < i; k++)
                    {
                        leftSum += myArray[k];
                    }
                }

                if (rightSum == leftSum)
                {
                    Console.WriteLine(i);
                    isEqual = true;
                }
            }
            if (isEqual == false)
            {
                Console.WriteLine("no");
            }
        }
    }
}
