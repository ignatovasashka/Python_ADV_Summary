﻿using System;
using System.Linq;

namespace MaxSequenceOfEqualElements
{
    class Program
    {
        static void Main()
        {
            int[] numbers = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();

            int startIndex = 0;
            int endIndex = 0;
            int longestSequence = 0;

            for (int i = 0; i < numbers.Length - 1; i++)
            {
                int currentSequence = 0;
                int currentEndIndex = 0;
                for (int j = i + 1; j < numbers.Length; j++)
                {
                    if (numbers[i] == numbers[j])
                    {
                        currentSequence++;
                        currentEndIndex = j;
                    }
                    else
                    {
                        break;
                    }
                }

                if (currentSequence > longestSequence)
                {
                    startIndex = i;
                    endIndex = currentEndIndex;
                    longestSequence = currentSequence;
                }
            }

            for (int i = startIndex; i <= endIndex; i++)
            {
                Console.Write($"{numbers[i]} ");
            }
        }
    }
}