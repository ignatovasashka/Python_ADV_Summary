﻿using System;
using System.Linq;

namespace P05
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] myNubers = Console.ReadLine()
                .Split()
                .Select(int.Parse)
                .ToArray();



            for (int i = 0; i < myNubers.Length; i++)
            {
                bool isBigger = true;
                for (int j = i + 1; j < myNubers.Length; j++)
                {
                    if (myNubers[j] >= myNubers[i])
                    {
                        isBigger = false;
                    }

                }
                if (isBigger)
                {
                    Console.Write(myNubers[i] + " ");
                }


            }
        }
    }
}