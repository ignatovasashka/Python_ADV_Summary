﻿using System;

namespace Arrays_Lab_Live
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
