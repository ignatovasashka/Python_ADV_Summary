﻿using System;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace _02Deciphering
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstLine = Console.ReadLine();
            string[] secondLine = Console.ReadLine().Split();
            string firstSubstring = secondLine[0];
            string secondSubstring = secondLine[1];


            StringBuilder sb = new StringBuilder(firstLine);

            for (int i = 0; i < sb.Length; i++)
            {
                char currentChar = sb[i];
                var newChar = currentChar - 3;

                sb[i] = (char)newChar;
            }

            string finalString = sb.Replace(firstSubstring, secondSubstring).ToString();

            bool isValid = firstLine.All(x=> "defghijklmnopqrstuvwxyz{}|#".Contains(x));

            if (isValid)
            {
                Console.WriteLine(finalString);
            }
            else
            {
                Console.WriteLine("This is not the book you are looking for.");
            }



        }
    }
}
