﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _01Dictionary
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] wordsAndDefinitions = Console.ReadLine().Split(" | ");
            string[] wordsMentioned = Console.ReadLine().Split(" | ");
            string endOrList = Console.ReadLine();

            var wordsAndDefinitionsInDictionary = new Dictionary<string, List<string>>();

            for (int i = 0; i < wordsAndDefinitions.Length; i++)
            {
                string[] wordAndDefinition = wordsAndDefinitions[i].Split(": ");
                string word = wordAndDefinition[0];
                string definition = wordAndDefinition[1];

                if (wordsAndDefinitionsInDictionary.ContainsKey(word) &&
                    !wordsAndDefinitionsInDictionary[word].Contains(definition))
                {
                    wordsAndDefinitionsInDictionary[word].Add(definition);

                }
                else
                {
                    wordsAndDefinitionsInDictionary.Add(word, new List<string>());
                    wordsAndDefinitionsInDictionary[word].Add(definition);

                }

            }

            for (int i = 0; i < wordsMentioned.Length; i++)
            {
                if (wordsAndDefinitionsInDictionary.ContainsKey(wordsMentioned[i]))
                {
                    Console.WriteLine($"{wordsMentioned[i]}:");

                    //foreach (var item in wordsAndDefinitionsInDictionary[wordsAndDefinitions[i]].OrderByDescending(x => x.Length))
                    //{
                    //    Console.WriteLine($" -{wordsAndDefinitionsInDictionary[wordsAndDefinitions[i]]}");
                    //
                    //}
                    
                }
            }

            if (endOrList == "List")
            {
                Console.WriteLine(string.Join(" ", wordsAndDefinitionsInDictionary.Keys.OrderBy(x=>x)));
            }
            

        }
    }
}
