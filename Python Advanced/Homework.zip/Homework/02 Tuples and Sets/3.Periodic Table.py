n = int(input())
compounds = set()

for _ in range(n):
    [compounds.add(i) for i in input().split()]

[print(element) for element in compounds]