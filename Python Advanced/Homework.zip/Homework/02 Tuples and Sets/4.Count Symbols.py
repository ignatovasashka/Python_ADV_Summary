text = input()
char = set()
counter = {}

for i in text:
    if i not in counter:
        counter[i] = 1
    else:
        counter[i] += 1

sorted_result = sorted(counter.items(), key = lambda x: x[0]) # x[1]-сортира по values; for descending sorting : -x[0] или reverse=True за стрингове
[print(f"{key}: {value} time/s") for key, value in sorted_result]