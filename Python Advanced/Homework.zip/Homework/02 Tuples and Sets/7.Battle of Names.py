n = int(input())

odd, even = set(), set()

for i in range(n):
    name = input()

    ascii_sum = 0
    for letter in name:
        ascii_sum += ord(letter)
    ascii_sum = ascii_sum // (i+1)

    if ascii_sum % 2 == 0:
        even.add(ascii_sum)
    else:
        odd.add(ascii_sum)

even_sum = sum(even)
odd_sum = sum(odd)


if even_sum == odd_sum:
    result = odd.union(even)
elif even_sum > odd_sum:
    result = odd.symmetric_difference(even)
elif odd_sum > even_sum:
    result = odd.difference(even)

print(', '.join([str(x) for x in result]))