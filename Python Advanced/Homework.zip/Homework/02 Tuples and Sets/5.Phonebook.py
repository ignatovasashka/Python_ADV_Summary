contacts = {}

while True:
    text = input()
    if text.isnumeric():
        n = int(text)
        break
    name, phone = text.split('-')
    contacts[name] = phone

for _ in range(n):
    name = input()
    if name in contacts:
        print(f'{name} -> {contacts[name]}')
    else:
        print(f'Contact {name} does not exist.')