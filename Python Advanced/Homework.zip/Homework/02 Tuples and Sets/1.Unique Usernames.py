n = int(input())
usernames_set = set()

for _ in range(n):
    usernames_set.add(input())

[print(name) for name in usernames_set]
#print(usernames_set)