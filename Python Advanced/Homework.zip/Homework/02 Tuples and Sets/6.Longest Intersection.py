n = int(input())
set_1 = set()
set_2 = set()
longest = set()
len_longest = 0

def adding(start, end, sets):
    for x in range(int(start), int(end)+1):
        sets.add(x)

for _ in range(n):
    ranges = input().split('-')
    first_start, first_end = ranges[0].split(',')
    second_start, second_end = ranges[1].split(',')

    adding(first_start,first_end,set_1)
    adding(second_start,second_end,set_2)
    new_set = set_1.intersection(set_2)

    if len(new_set) > len_longest:
        longest = new_set
        len_longest = len(longest)
    set_1.clear()
    set_2.clear()

result = map(str, longest)
print(f'Longest intersection is [{", ".join(result)}] with length {len_longest}')
