# problem 2 from another exam - Darts

first_player, second_player = input().split(", ")
dartboard = []
n = 7
coordinates = []

for _ in range(n):
    dartboard.append(input().split())

while True:
    coordinates.append(tuple([int(el) for el in (input()[1:][:-1].split(", "))]))

    for throw in coordinates:
        if throw == (3, 3):
            break
            break
print(f"{name} won the game with {count_turns} throws!")
