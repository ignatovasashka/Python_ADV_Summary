from collections import deque


def stock_availability(inventory_list, action, *args):

    inventory_list = deque(inventory_list)
    if action == "delivery":
        for box in args:
            inventory_list.append(box)
    elif action == "sell":
        if any(args):
            for param in args:
                if isinstance(param, int):
                    for _ in range(param):
                        inventory_list.popleft()
                else:
                    for i in inventory_list.copy():
                        if (i == param):
                            inventory_list.remove(i)
        else:
            inventory_list.popleft()

    return list(inventory_list)


print(stock_availability(["chocolate", "vanilla", "banana"], "sell", "cookie"))
