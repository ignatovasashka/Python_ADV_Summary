from collections import deque

effects = deque(int(el) for el in input().split(", "))
powers = list(int(el) for el in input().split(", "))
mixture = 0
count_palm, count_willow, count_crossette = 0, 0, 0

for e in effects.copy():
    if e <= 0:
        effects.remove(e)
for p in powers.copy():
    if p <= 0:
        powers.remove(p)

while (count_palm < 3 or count_willow < 3 or count_crossette < 3) \
        and len(effects) >= 1 and len(powers) >= 1:
    for e in effects.copy():
        for p in reversed(powers.copy()):
            mixture = e + p
            if mixture % 3 == 0 and mixture % 5 != 0:
                count_palm += 1
                effects.popleft()
                powers.pop()
                break
            elif mixture % 5 == 0 and mixture % 3 != 0:
                count_willow += 1
                effects.popleft()
                powers.pop()
                break
            elif mixture % 5 == 0 and mixture % 3 == 0:
                count_crossette += 1
                effects.popleft()
                powers.pop()
                break
            else:
                e -= 1
                effects.popleft()
                effects.appendleft(e)
                effects.rotate(-1)
                break

if count_palm >= 3 and count_willow >= 3 and count_crossette >= 3:
    print("Congrats! You made the perfect firework show!")
else:
    print("Sorry. You can't make the perfect firework show.")

if len(effects) >= 1:
    print(f"Firework Effects left:", ", ".join([str(el) for el in effects]))
if len(powers) >= 1:
    print(f"Explosive Power left:", ", ".join([str(el) for el in powers]))

print(f"Palm Fireworks: {count_palm}")
print(f"Willow Fireworks: {count_willow}")
print(f"Crossette Fireworks: {count_crossette}")
