n = int(input())

matrix = []
result = 0
sum_primary = 0
sum_secondary = 0

for row in range(n):
    matrix.append([int(el) for el in input().split()])


for row in range(n):
    for col in range(n):
        if row == col:
            sum_primary += matrix[row][col]
        if row == n -1 - col:
            sum_secondary += matrix[row][col]

result = abs(sum_primary - sum_secondary)
print(result)