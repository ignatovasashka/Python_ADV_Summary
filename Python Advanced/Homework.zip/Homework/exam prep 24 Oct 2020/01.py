# from collections import deque
#
# tasks = [int(el) for el in (input().split(", "))]
#
# searched_index = int(input())
#
# cycles = deque(sorted([(tasks[index], index) for index in range(len(tasks))]))
#
# result = 0
#
# while cycles:
#     number, index = cycles.popleft()
#     result += number
#     if index == searched_index:
#         print(result)
#         break

tasks = [int(el) for el in (input().split(", "))]
searched_index = int(input())
total_cycles = 0
cycles = sorted(tasks, key=lambda x: (x, tasks.index(x)))
element = tasks[searched_index]

for task in cycles:
    if element not in tasks:
        break
    total_cycles = task + total_cycles
    tasks.remove(task)

print(total_cycles)