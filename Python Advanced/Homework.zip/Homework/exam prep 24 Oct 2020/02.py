matrix = []
n = 8

for _ in range(n):
    matrix.append(input().split())

directions = {
    "up": (-1, 0),
    "down": (1, 0),
    "left": (0, -1),
    "right": (0, 1),
    "up_right": (-1, -1),
    "up_left": (-1, 1),

}