def is_in_range(row, col):
    if 0 <= row < 5 and 0 <= col < 5:
        return True
    return False

matrix = []
player_position = None
x_count = 0
x_shot = 0
positions_shot = []

for row in range(5):
    row_data = input().split()
    if "A" in row_data:
        player_position = [row, row_data.index("A")]
    matrix.append(row_data)

count_of_commands = int(input())

for row in range(5):
    for col in range(5):
        if matrix[row][col] == "x":
            x_count += 1

directions = {
    "up": (-1, 0),
    "down": (1, 0),
    "left": (0, -1),
    "right": (0, 1)
}

for _ in range(count_of_commands):
    line = input().split()
    if line[0] == "move":
        command = line[0]
        direction = line[1]
        steps = int(line[2])
        for i in range(steps):
            if direction in directions:
                next_row = player_position[0] + directions[direction][0]
                next_col = player_position[1] + directions[direction][1]
                if is_in_range(next_row, next_col) and not matrix[next_row][next_col] == "x":
                    player_position = [next_row, next_col]

    elif line[0] == "shoot":
        direction = line[1]
        current_shot_position_row = player_position[0]
        current_shot_position_col = player_position[1]

        while is_in_range(current_shot_position_row, current_shot_position_col) and x_count - x_shot > 0:

            if matrix[current_shot_position_row][current_shot_position_col] == "x":
                matrix[current_shot_position_row][current_shot_position_col] = "."
                x_shot += 1
                positions_shot.append([current_shot_position_row, current_shot_position_col])
                break

            current_shot_position_row = current_shot_position_row + directions[direction][0]
            current_shot_position_col = current_shot_position_col + directions[direction][1]

if (x_count - x_shot) == 0:
    print(f"Training completed! All {x_count} targets hit.")
else:
    print(f"Training not completed! {x_count - x_shot} targets left.")


if any(positions_shot):
    for el in positions_shot:
        print(el)
