from collections import deque


def is_in_range(dictionary):
    if all([value >= 5 for value in dictionary.values()]):
        return True
    return False


chocolates = [int(x) for x in input().split(", ")]
cups = [int(x) for x in input().split(", ")]

chocolates = deque(chocolates)
cups = deque(cups)

dict_shakes = {
    "Shake": 0}

while len(chocolates) > 0 and len(cups) > 0 and not is_in_range(dict_shakes):
    first_cup = cups.popleft()
    last_chocolate = chocolates.pop()

    if first_cup <= 0:
        chocolates.append(last_chocolate)
    elif last_chocolate <= 0:
        cups.appendleft(first_cup)
    elif first_cup == last_chocolate :
        dict_shakes['Shake'] += 1
        managed_to_create = True

    else:
        last_chocolate -= 5
        cups.append(first_cup)

if not is_in_range(dict_shakes):
    print(f"Not enough milkshakes.")
    if len(chocolates) >= 1:
        print(f"Chocolate: {', '.join(map(str, chocolates))}")
    else:
        print(f"Chocolate: empty")

    if len(cups) >= 1:
        print(f"Milk: {', '.join(map(str, cups))}")
    else:
        print(f"Milk: empty")
else:
    print(f"Great! You made all the chocolate milkshakes needed!")
    if len(chocolates) >= 1:
        print(f"Chocolate: {', '.join(map(str, chocolates))}")
    else:
        print(f"Chocolate: empty")

    if len(cups) >= 1:
        print(f"Milk: {', '.join(map(str, cups))}")
    else:
        print(f"Milk: empty")

