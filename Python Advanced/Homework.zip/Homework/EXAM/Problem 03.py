from collections import deque


def math_operations(*args, **kwargs):

    numbers = deque(args)
    result = 0

    for i in range(len(numbers.copy())):
        if any(numbers):
            first = numbers.popleft()
            result = kwargs["a"] + first
            kwargs["a"] = result

            if any(numbers):
                second = numbers.popleft()
                result = kwargs["s"] - second
                kwargs["s"] = result

                if any(numbers):
                    third = numbers.popleft()
                    if third == 0:
                        pass
                    else:
                        result = kwargs["d"] / third
                        kwargs["d"] = result

                    if any(numbers):
                        fourth = numbers.popleft()
                        result = kwargs["m"] * fourth
                        kwargs["m"] = result

    return kwargs

print(math_operations(2, 12, 0, -3, 6, -20, -11, a=1, s=7, d=33, m=15))
print(math_operations(2, 12, 0, -3, 6, -20, 7, a=1, s=7, d=33, m=15))
print(math_operations(-1, 0, 1, 0, 6, -2, 80, a=0, s=0, d=0, m=0))
print(math_operations(6, a=0, s=0, d=0, m=0))
print(math_operations(a=5, s=2, d=4, m=8))