from collections import deque

chocolates = list(int(el) for el in input().split(", "))
cups = deque(int(el) for el in input().split(", "))
count = 0

for e in chocolates.copy():
    if e <= 0:
        chocolates.remove(e)
for p in cups.copy():
    if p <= 0:
        cups.remove(p)

while (count < 5 ) and len(chocolates) >= 1 and len(cups) >= 1:
    for cu in cups.copy():
        for ch in reversed(chocolates.copy()):
            if ch == cu:
                count += 1
                cups.popleft()
                chocolates.pop()
                break
            else:
                ch -= 5
                cups.rotate(-1)
                break

if count >= 5:
    print("Great! You made all the chocolate milkshakes needed!")
else:
    print("Not enough milkshakes.")

if len(cups) >= 1:
    print(f"Milk:", ", ".join([str(el) for el in cups]))
else:
    print(f"Milk: empty")

if len(chocolates) >= 1:
    print(f"Chocolate:", ", ".join([str(el) for el in chocolates]))
print(f"Chocolate: empty")
